firebaseSnippets
================

Sublime text 2 & 3 snippets for firebase javascript API

Install "Firebase Snippets" with Sublime Package Control, or download from here and unzip into Packages/Firebase Snippets.

Hope these help.

Feel free to make this better by improving existing snippets, adding other snippets, etc.
