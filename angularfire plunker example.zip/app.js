var app = angular.module('plunker', ['firebase']);

app.controller('MainCtrl', function($scope, angularFire, angularFireCollection) {
  
  // set up my model
  angular.extend($scope, {
    items: [],
    someItems: [],
    newItem: '',
    myItems: {}
  });

  // point at my Firebase location
  var ref = new Firebase('https://examples.firebaseio.com/orderedItems');
  
  // load the items into an angularFireCollection
  // i have to use angularFireCollection here or I'll lose my priorities
  // https://github.com/firebase/angularFire/issues/116
  $scope.items = angularFireCollection(ref);
  // using angularFire loses the order of priorities
  // and when the location is modified (an item is added or 
  // removed, the priority for that item is lost forever)
  // angularFire(ref, $scope, 'items');
  
  // limit a set using priorities, results will be out of order!
  angularFire(ref.startAt('A').endAt('L'), $scope, 'someItems');
  // explicit data binding works on limiting as well
  // $scope.someItems = angularFireCollection(ref.startAt('A').endAt('L'));
  
  // the add function will add an item to the orderedItems location
  $scope.add = function() {
    
    // only save it if there's some text
    if ($scope.newItem.length > 0) {
      
      // when an item is added to the angularFireCollection, 
      // i get a handle on the ref
      var ref = $scope.items.add({ name: $scope.newItem })
        .setPriority($scope.newItem);
      
      // empty out newItem
      $scope.newItem = '';
    }
  };
  
});
